#app/schemas/auth.py

from pydantic import BaseModel,EmailStr


class RegisterRequest(BaseModel):
    email:EmailStr
    password:str
    
class LoginRequest(BaseModel):
    email:EmailStr
    password:str